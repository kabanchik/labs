package com.company;

/**
 * Created by andre on 20.09.2016.
 */
public class ura {
    public static void main(String[] args) {
        test t=new test();
        t.logika(1,2,3);
        t.poka(100);
        double[] A ={2,4,6,8,10,12};
        t.massivy(A ,2,3);
    }
}